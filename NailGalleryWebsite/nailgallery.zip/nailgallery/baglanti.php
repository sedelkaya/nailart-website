<?php
$vt_sunucu="localhost";
$vt_kullanici="root";
$vt_sifre="";
$vt_adi="nailgallery";

$baglan=mysqli_connect($vt_sunucu, $vt_kullanici, $vt_sifre, $vt_adi);

if(!$baglan)
{
    die("Veritabanı bağlantı işlemi başarısız.".mysqli_connect_error());
}


?>

<?php

$vt_sunucu = "localhost";
$vt_kullanici = "root";
$vt_sifre = "";
$vt_adi = "nailgallery";

$baglan = new mysqli($vt_sunucu, $vt_kullanici, $vt_sifre, $vt_adi);

if ($baglan->connect_error) {
    die("Bağlantı hatası: " . $baglan->connect_error);
}

$isim = $_POST['isim'];
$soyisim = $_POST['soyisim'];
$email = $_POST['email'];
$telno = $_POST['telno'];

$ekle = "INSERT INTO iletisim (ad, soyad, email, telefon) VALUES ('$isim', '$soyisim', '$email', '$telno')";

if ($baglan->query($ekle) === TRUE) {
  echo "<script>alert('Teşekkürler.En kısa zamanda size ulaşacağız.')</script>";
} else {
  echo "<script>alert('Bir hata oluştu. Lütfen tekrar deneyin.')</script>";
}

$baglan->close();
?>