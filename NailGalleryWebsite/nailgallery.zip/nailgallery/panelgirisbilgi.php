<?php

session_start();

if(isset($_POST["usrnm"], $_POST["psw"]))
{
  if($_POST["usrnm"]=="admin" && $_POST["psw"]=="1234")
  {
    $_SESSION["user"]=$_POST["usrnm"];
    header("location:panel.php");
  }

  else
  {
    echo "<script>alert('Kullanıcı adı veya şifre yanlış.')</script>";
  }

}


?>