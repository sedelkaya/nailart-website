<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <link href="https://fonts.googleapis.com/css2?family=Raleway:ital,wght@0,300;1,100;1,200&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="css/style.css">
    

    <title>NailGallery || Parmak Uçlarındaki Sanat...</title>
  </head>
  <body>
   
    <!-- MENÜ KISMI BAŞLANGIÇ-->

    <nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
        <a class="navbar-brand" href="#">NAİLGALLERY || Parmak Uçlarındaki Sanat...</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-end" id="navbarNavDropdown">
          <ul class="navbar-nav">
            <li class="nav-item active">
              <a class="nav-link" href="#menu">Anasayfa<span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#hakkimizda">Hakkımızda</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#ekibimiz">Ekibimiz</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#galeri">Galeri</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#randevu">Randevu</a>
            </li>
           
          </ul>
        </div>
      </nav>

    <!-- MENÜ KISMI BİTİŞ-->

    <!-- SLİDER BAŞLANGIÇ-->

    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
          <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
          <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
          <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
        </ol>
        <div class="carousel-inner">
          <div class="carousel-item active">
            <img class="d-block w-100" src="img/sl1.jpeg" alt="First slide">
          </div>
          <div class="carousel-item">
            <img class="d-block w-100" src="img/sl2.jpeg" alt="Second slide">
          </div>
          <div class="carousel-item">
            <img class="d-block w-100" src="img/sl3.jpeg" alt="Third slide">
          </div>
        </div>
        <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="sr-only">Next</span>
        </a>
      </div>

    <!--SLİDER BİTİŞ-->

    <!-- HAKKIMIZDA BAŞLANGIÇ-->
    <section class="p-5 text-center hakkimizda">
        <div class="container">

            <h2 class="mb-5 font-weight-bold " > Hakkımızda</h2>
            

            <hr>

            <p>Selamlar! Biz NailGallery, tırnaklarınızı sanat eserine dönüştüren bir ekibiz. Nail art konusundaki tutkumuz ve deneyimimizle, müşterilerimize özel ve yaratıcı tırnak tasarımları sunuyoruz. Her müşterimiz benzersizdir ve tırnak tasarımlarımız da öyle. İstediğiniz renk, desen veya tema üzerinden kişiselleştirilmiş tırnak sanatı tasarımları sunuyoruz.</p>

            <p>Misyonumuz, müşterilerimize benzersiz, özgün ve kaliteli nail art deneyimleri sunarak onların kendilerini özel hissetmelerini sağlamaktır. Tırnaklarınız, sanatı ifade etmenin bir yolu olabilir ve biz size bu konuda yardımcı olmaktan mutluluk duyarız.Moda ve güzellik dünyasındaki son trendleri takip ediyoruz. Sizlere her zaman en yeni ve güncel tırnak tasarımlarını sunmak için çabalıyoruz.</p>




        </div>
    </section>

    <!-- HAKKIMIZDA BİTİŞ-->

    <!--EKİBİMİZ BAŞLANGIÇ-->
    <section class="p-5 text-center ekibimiz">
        <div class="container">

            <h2 class="mb-5 font-weight-bold " > Ekibimiz</h2>
            

            <hr>
        
                
            
            <div class="card-deck">
                <div class="card shadow ekipCard">
                    <img src="img/artist1.jpg" class="card-img-top" alt="">
                    <div class="card-body">
                        <h5 class="card-title font-weight-bold">Yasemin Canlı</h5>
                        <p class="card-text">Salon Müdürü</p>
                    </div>
                </div>
                <div class="card ekipCard">
                    <img src="img/artist2.jpg" class="card-img-top" alt="">
                    <div class="card-body">
                        <h5 class="card-title font-weight-bold">Buse Uslu</h5>
                        <p class="card-text">Tırnak Uzmanı</p>
                    </div>
                </div>
                <div class="card ekipCard">
                    <img src="img/artist3.jpg" class="card-img-top" alt="">
                    <div class="card-body">
                        <h5 class="card-title font-weight-bold">Işıl Narlı</h5>
                        <p class="card-text">Renk Uzmanı</p>
                    </div>
               
                
            </div>
       



        </div>
    </section>



    <!--EKİBİMİZ BİTİŞ-->

    <!--GALERİ BAŞLANGIÇ-->

    <section class="p-5 text-center galeri">
        <div class="container">

            <h2 class="mb-5 font-weight-bold " > Galeri</h2>
            

            <hr>
        <div class="row">
            <div class="col-md-3">
                <figure class="figure">
                    <a href="img/galeri1.jpg">
                    <img src="img/galeri1.jpg" class="figure-img img-fluid rounded shadow" alt="A generic square placeholder image with rounded corners in a figure.">
                     </a>
                  </figure>
            </div>
            <div class="col-md-3">
                <figure class="figure">
                    <a href="img/galeri2.jpg">
                    <img src="img/galeri2.jpg" class="figure-img img-fluid rounded shadow" alt="A generic square placeholder image with rounded corners in a figure.">
                     </a>
                  </figure>
            </div>
            <div class="col-md-3">
                <figure class="figure">
                    <a href="img/galeri3.jpg">
                    <img src="img/galeri3.jpg" class="figure-img img-fluid rounded shadow" alt="A generic square placeholder image with rounded corners in a figure.">
                     </a>
                  </figure>
            </div>
            <div class="col-md-3">
                <figure class="figure">
                    <a href="img/galeri4.jpg">
                    <img src="img/galeri4.jpg" class="figure-img img-fluid rounded shadow" alt="A generic square placeholder image with rounded corners in a figure.">
                     </a>
                  </figure>
            </div>
        </div>
        <div class="row">
            <div class="col-md-3">
                <figure class="figure">
                    <a href="img/galeri5.jpg">
                    <img src="img/galeri5.jpg" class="figure-img img-fluid rounded shadow" alt="A generic square placeholder image with rounded corners in a figure.">
                     </a>
                  </figure>
            </div>
            <div class="col-md-3">
                <figure class="figure">
                    <a href="img/galeri6.jpg">
                    <img src="img/galeri6.jpg" class="figure-img img-fluid rounded shadow" alt="A generic square placeholder image with rounded corners in a figure.">
                     </a>
                  </figure>
            </div>
            <div class="col-md-3">
                <figure class="figure">
                    <a href="img/galeri7.jpg">
                    <img src="img/galeri7.jpg" class="figure-img img-fluid rounded shadow" alt="A generic square placeholder image with rounded corners in a figure.">
                     </a>
                  </figure>
            </div>
            <div class="col-md-3">
                <figure class="figure">
                    <a href="img/galeri8.jpg">
                    <img src="img/galeri8.jpg" class="figure-img img-fluid rounded shadow" alt="A generic square placeholder image with rounded corners in a figure.">
                     </a>
                  </figure>
            </div>
        </div>

        </div>
    </section>
    <!--GALERİ BİTİŞ-->


    <!--İLETİSİM BAŞLANGIÇ-->
    <section class="p-5 text-center randevu">
        <div class="container">
            <div class="image-container">
                <img src="img/rezervasyon.jpeg">
            </div>
            <div class="text-container">
                <h2 id="iletisim">Size Ulaşalım</h2>

                <img class="rezervasyonfotosu" src="img/nailGaleriİcon.png" alt="" width="50" height="50" >
                   
                <hr>
    
                <form action="index.php" method="post">
                    <div class="form-row">
                      <div class="form-group col-md-6 text-left">
                        <label for="inputİsim">İsim*</label>
                        <input type="isim" class="form-control" id="inputisim" placeholder="İsim" name=isim>
                      </div>
                      <div class="form-group col-md-6">
                        <label for="inputSoyisim">Soy İsim</label>
                        <input type="soyisim" class="form-control" id="inputSoyisim" placeholder="Soy İsim" name=soyisim>
                      </div>
                      <div class="form-group col-md-6">
                        <label for="inputEmail">E-Posta*</label>
                        <input type="email" class="form-control" id="inputEmail" placeholder="E-Posta" name=email>
                      </div>
                      <div class="form-group col-md-6">
                        <label for="inputTelNo">Telefon Numarası*</label>
                        <input type="telNo" class="form-control" id="inputTelNo" placeholder="Telefon Numarası" name=telno>
                      </div>
                     
                      <button type="submit" class="buton">Gönder</button>

                    


                      <div class="contact-info">
                        <p>Adres: Beytepe Mah. 5432.Cad, Ankara, Türkiye</p>
                        <p>Telefon: (123) 456-7890</p>
                        <p>E-posta: nailgallery@example.com</p>
                    
                        <div class="social-icons">
                            <a href="https://www.facebook.com/" target="_blank"><img src="img/facebook.png" alt="Facebook"  width="30" height="30"></a>
                            <a href="https://twitter.com/" target="_blank"><img src="img/twitter.png" alt="Twitter" width="30" height="30"></a>
                            <a href="https://www.instagram.com/" target="_blank"><img src="img/instagram.png" alt="Instagram" width="30" height="30"></a>
                        </div>
                    
                        <p class="working-hours">Çalışma Saatleri: Pazartesi - Cuma: 9:00 - 17:00</p>
                    </div>
                    
            </div>
        </div>
                  
                </div>
                

              </form>

    <!--İLETİSİM BİTİŞ-->
    








   






    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  </body>
</html>

